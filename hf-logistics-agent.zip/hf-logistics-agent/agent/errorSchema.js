export const ERROR_SCHEMA = `
ERROR HANDLING:
If required data is missing or tools fail:
{
  "error": "Missing or invalid data",
  "required_fields": [list]
}
`;